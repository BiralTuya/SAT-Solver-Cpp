#!/bin/sh

##### C++
g++ -std=c++17 -o solve-cpp example.cpp

##### Java
#javac example.java

##### Python
# nothing to do for python
